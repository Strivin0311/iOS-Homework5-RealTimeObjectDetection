//
//  ViewController.swift
//  RealTimeObjectDetection
//
//  Created by strivin on 2020/11/8.
//

import UIKit
import AVKit
import Vision

class ViewController: UIViewController,AVCaptureVideoDataOutputSampleBufferDelegate {
    
    @IBOutlet var resultLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        resultLabel.layer.cornerRadius = 20
        
        // 启动捕捉任务
        let captureSession = AVCaptureSession()
        captureSession.sessionPreset = .photo

        guard let device = AVCaptureDevice.default(for: .video) else{ return } // 使用录像设备
        guard let input = try? AVCaptureDeviceInput(device: device) else{ return } // 使用录像设备的输入
        captureSession.addInput(input) // 输入

        captureSession.startRunning() // 启动任务

        let previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        view.layer.addSublayer(previewLayer)
        previewLayer.frame = CGRect(x: 20, y: 20, width: 800, height: 1000) // 添加视图的捕捉层
        previewLayer.cornerRadius = 5

        let dataOutput = AVCaptureVideoDataOutput()
        dataOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        captureSession.addOutput(dataOutput) //输出
    }
    
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        
        guard let cvpixelbuffer:CVPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else{return}
        // 利用已有mlmodel,建立一个VNCoreMLModel模型
        guard let model = try? VNCoreMLModel(for: cifar10_net(configuration: MLModelConfiguration()).model) else{return}
        // 利用该model，建立一个VNCoreMLRequest的请求
        // 并在其中得到结果results
        let request = VNCoreMLRequest(model: model) { (finishedReq, err) in
            //print(finishedReq.results)
            
            guard let results = finishedReq.results as? [VNClassificationObservation] else{return}
            
            guard let firstObservation = results.first else{return}
            
            //print(firstObservation.identifier,firstObservation.confidence)
             //修改label的text,注意必须放到主线程队列中，以免线程不安全
            DispatchQueue.main.async {
                let id = firstObservation.identifier
                var conf = firstObservation.confidence/10
                if (conf > 90){
                    let bias = conf / 100
                    conf = 90 + bias
                }
                    
                self.resultLabel!.text = "identifier:\(id) || confidence:\((conf).rounded())%"
            }
            
        }
        // 通过VNImageRequestHandle执行该请求
        try? VNImageRequestHandler(cvPixelBuffer: cvpixelbuffer, options: [:]).perform([request])
        
    }

}

