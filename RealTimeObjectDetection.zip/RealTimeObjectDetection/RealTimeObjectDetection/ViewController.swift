//
//  ViewController.swift
//  RealTimeObjectDetection
//
//  Created by strivin on 2020/11/8.
//

import UIKit
import AVKit
import Vision

class ViewController: UIViewController,AVCaptureVideoDataOutputSampleBufferDelegate {
    
    @IBOutlet var resultLabel: UILabel!
    @IBOutlet var VideoView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // 设置结果标签
        setResultLabel()
        // 设置屏幕捕捉层
        setVideoCapture()
    }
    
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        
        guard let cvpixelbuffer:CVPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else{return}
        // 利用已有mlmodel,建立一个VNCoreMLModel模型
        guard let model = try? VNCoreMLModel(for: cifar10_net(configuration: MLModelConfiguration()).model) else{return}
        // 利用该model，建立一个VNCoreMLRequest的请求
        // 并在其中得到结果results
        let request = VNCoreMLRequest(model: model) { (finishedReq, err) in
            
            guard let results = finishedReq.results as? [VNClassificationObservation] else{return}
            
            guard let firstObservation = results.first else{return}
            
             //修改label的text,注意必须放到主线程队列中，以免线程不安全
            DispatchQueue.main.async {
                let id = firstObservation.identifier
                let conf = String(format: "%.1f%%", firstObservation.confidence * 100)
                    
//                self.resultLabel!.text = "identifier:\(id) || confidence:\(conf)"
                self.resultLabel!.text = "It's maybe a(an) \(id)"
            }
            
        }
        // 通过VNImageRequestHandle执行该请求
        try? VNImageRequestHandler(cvPixelBuffer: cvpixelbuffer, options: [:]).perform([request])
        
    }

    func setVideoCapture(){
        // 启动捕捉任务
        let captureSession = AVCaptureSession()
        captureSession.sessionPreset = .photo

        guard let device = AVCaptureDevice.default(for: .video) else{ return } // 使用录像设备
        guard let input = try? AVCaptureDeviceInput(device: device) else{ return } // 使用录像设备的输入
        captureSession.addInput(input) // 输入

        captureSession.startRunning() // 启动任务

        let previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        //previewLayer.frame  = VideoView.layer.frame
        VideoView.layer.addSublayer(previewLayer)
        previewLayer.frame = CGRect(x: 0, y: 20, width: 830, height: 900) // 添加视图的捕捉层
        
        //previewLayer.addSublayer(resultLabel.layer)

        let dataOutput = AVCaptureVideoDataOutput()
        dataOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        captureSession.addOutput(dataOutput) //输出
    }
    
    func setResultLabel(){
        resultLabel.layer.cornerRadius = 20
    }
}

